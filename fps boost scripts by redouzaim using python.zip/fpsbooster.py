
import psutil

def boost_fps():
    # Set the process priority to high
    psutil.Process().nice(psutil.HIGH_PRIORITY_CLASS)
    
    # Set CPU affinity to use all available CPU cores
    num_cores = psutil.cpu_count()
    current_process = psutil.Process()
    current_process.cpu_affinity(list(range(num_cores)))
    
    print("FPS boosted!")

if __name__ == "__main__":
    boost_fps()

