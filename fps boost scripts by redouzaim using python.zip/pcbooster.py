
import psutil
import os
import time

def boost_pc():
    # Set CPU governor mode to performance
    os.system("sudo cpupower frequency-set -g performance")
    
    # Disable unwanted startup programs
    startup_programs = ["program1.exe", "program2.exe", "program3.exe"]
    for program in startup_programs:
        os.system(f"sudo sed -i '/{program}/d' /etc/xdg/autostart/*.desktop")
    
    # Clear RAM cache
    os.system("sudo sh -c 'echo 3 > /proc/sys/vm/drop_caches'")
    
    # Limit the number of running processes
    max_processes = 50
    current_processes = psutil.cpu_count()
    if current_processes > max_processes:
        for _ in range(current_processes - max_processes):
            os.fork()
    
    # Set CPU affinity to the first core
    pid = os.getpid()
    os.system(f"taskset -p 0x00000001 {pid}")
    
    # Execute a heavy task to fully utilize the CPU
    for _ in range(10):
        for _ in range(10**8):
            pass
    
    # Reset CPU governor mode to powersave
    os.system("sudo cpupower frequency-set -g powersave")
    print("PC Have been boosted this app by Redouzaim")
    
# Run PC booster
if __name__ == "__main__":
    boost_pc()
    

