
import os
import shutil


def remove_temp_files():
    temp_folder = os.path.join(os.environ.get("USERPROFILE"), "AppData", "Local", "Temp")
    for root, dirs, files in os.walk(temp_folder):
        for file in files:
            try:
                file_path = os.path.join(root, file)
                os.remove(file_path)
                print(f"Deleted {file_path}")
            except Exception as e:
                print(f"Failed to delete {file_path}: {str(e)}")


def empty_recycle_bin():
    try:
        shell = win32com.client.Dispatch("Shell.Application")
        recycle_bin = shell.NameSpace(10)
        items = recycle_bin.Items()
        for item in items:
            recycle_bin.invokeverb("Empty Recycle Bin")
            print("Recycle Bin emptied successfully")
    except Exception as e:
        print(f"Failed to empty Recycle Bin: {str(e)}")


def free_up_disk_space():
    remove_temp_files()
    empty_recycle_bin()


if __name__ == "__main__":
    free_up_disk_space()

